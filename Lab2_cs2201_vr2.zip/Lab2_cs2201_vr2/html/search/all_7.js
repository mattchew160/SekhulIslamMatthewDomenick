var searchData=
[
  ['operator_3d',['operator=',['../class_b_s_tree.html#ac36b0b564aa3c411c239d730f506f448',1,'BSTree']]]
];
