//Author : Matthew Domnick and Sekhul Islam
//date : 11/1/17
//version: 2.0






#include <iostream>
#include <cctype>
#include <stack>
#include <string>
using namespace std;

// returns the value when a specific operator
// operates on two operands
double eval(double op1, double op2, char operate) {
	switch (operate) {
	case '*': return op2 * op1;
	case '/': return op2 / op1;
	case '+': return op2 + op1;
	case '-': return op2 - op1;
	default: return 0;
	}
}

// evaluates the postfix operation
// it's a simple function which implements the basic logic to
// evaluate postfix operations using stack
double evalPostfix(string postfix) {
	stack<double> s;
	int i = 0;
	char ch;
	double val;
	int size = postfix.length();
	while (i < size) {
		ch = postfix[i];
		if (isdigit(ch)) {
			// we saw an operand
			// push the digit onto stack
			s.push(ch - '0');
		}
		else {
			// we saw an operator
			// pop off the top two operands from the
			// stack and evalute them using the current
			// operator
			double op1 = s.top();
			s.pop();
			double op2 = s.top();
			s.pop();
			val = eval(op1, op2, ch);
			// push the value obtained after evaluating
			// onto the stack
			s.push(val);
		}
		i++;
	}
	return val;
}

// main
int main() {

	string statement;
	cout << "Enter expression in postfix form : ";
	getline(cin, statement);
	double val = evalPostfix(statement);
	cout << "\nExpression evaluates to " << val;
	cout << endl;
	system("pause");
	return 0;
}
