// show6.cpp
//	Author: Matthew Domenick and Sekhul Islam
//	Date: 10/26/17
// Version : 1.0
#include"Stack.h"

#include"StackArray.h"

#include"StackLinked.h"

using namespace std;

//--------------------------------------------------------------------

template <typename DataType>
void StackArray<DataType>::showStructure() const

// Array implementation. Outputs the data items in a stack. If the
// stack is empty, outputs "Empty stack". This operation is intended
// for testing and debugging purposes only.

{
	if (isEmpty()) {
		cout << "Empty stack." << endl;
	}
	else {
		int j;
		cout << "Top = " << top << endl;
		for (j = 0; j < maxSize; j++)
			cout << j << "\t";
		cout << endl;
		for (j = 0; j <= top; j++)
		{
			if (j == top)
			{
				cout << '[' << dataItems[j] << ']' << "\t"; // Identify top
			}
			else
			{
				cout << dataItems[j] << "\t";
			}
		}
		cout << endl;
	}
	cout << endl;
}

template <type DataType>
bool StackArray<DataType>::isEmpty() const
{
	
	if (top == 1)
		return false;
	else
		return true;



	
}

template<template DataType>
bool StackArray < DataType::isFull()const
{
	if (top == max_size)
		return true;
	else
		return false;




}


template<template DataType>
void StackArray < DataType::isClear()
{
	int count = 0;
	for (maxSize-1)
	{
		dataItems&[count] = NULL;

		count = count + 1;



	}






}

template<template DataType>
DataType StackArray < DataType::pop()
{
	int temp_1
	dataItems = NULL;
	maxSize = maxSize - 1;		//stoped here
	int temp = maxSize;
	dataType.top = temp;




	return dataItems;
}






~StackArray();













//--------------------------------------------------------------------

template <typename DataType>
void StackLinked<DataType>::showStructure() const

// Linked list implementation. Outputs the data elements in a stack.
// If the stack is empty, outputs "Empty stack". This operation is
// intended for testing and debugging purposes only.

{
	if (isEmpty())
	{
		cout << "Empty stack" << endl;
	}
	else
	{
		cout << "Top\t";
		for (StackNode* temp = top; temp != 0; temp = temp->next) {
			if (temp == top) {
				cout << '[" << temp->dataItem << "]\t";
			}
			else {
				cout << temp->dataItem << "\t";
			}
		}
		cout << "Bottom" << endl;
	}

}
























